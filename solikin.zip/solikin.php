<?php
system('clear');
// Fungsi untuk menambahkan warna pada teks
function colorText($text, $color) {
    $colors = [
        'green' => "\033[32m",
        'red' => "\033[31m",
        'yellow' => "\033[33m",
        'blue' => "\033[34m",
        'cyan' => "\033[36m",
        'reset' => "\033[0m"
    ];
    return $colors[$color] . $text . $colors['reset'];
}

// Fungsi untuk menampilkan header dengan border
function displayHeader($text) {
    $border = str_repeat("=", strlen($text) + 4);
    echo colorText("\n$border\n", 'cyan');
    echo colorText("= $text =\n", 'cyan');
    echo colorText("$border\n", 'cyan');
}

// Fungsi untuk mengunduh file
function downloadFile($file_url, $save_to) {
    echo colorText("Data Downloading Procces...\n", 'blue');

    $ch = curl_init($file_url);
    $fp = fopen($save_to, 'wb');
    $progress = 0;  // Inisialisasi progress

    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_NOPROGRESS, false);    // Aktifkan progress
    curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, function(
        $resource, $download_size, $downloaded, $upload_size, $uploaded
    ) use (&$progress) {
        if ($download_size > 0) {
            $progress = round($downloaded / $download_size * 100);
            echo colorText("Progress on : $progress% (".round($downloaded/1024, 2)." KB dari ".round($download_size/1024, 2)." KB)\r", 'yellow');
        }
    });
    curl_setopt($ch, CURLOPT_BUFFERSIZE, 128000);   // Ukuran buffer untuk progres unduhan

    // Eksekusi unduhan
    curl_exec($ch);

    // Tutup resource
    curl_close($ch);
    fclose($fp);

    echo colorText("Download selesai!\n", 'green');
}

// Fungsi untuk menampilkan progres ekstraksi
function extractProgress($file_path, $extract_to) {
    echo colorText("Loading Progress...\n", 'blue');

    $total_files = 0;
    $current_file = 0;

    // Hitung total file untuk progres
    exec("tar -tzf $file_path | wc -l", $output);
    $total_files = (int)trim($output[0]);

    if ($total_files > 0) {
        $process = proc_open("tar -xvzf $file_path -C $extract_to", [
            1 => ["pipe", "w"],
            2 => ["pipe", "w"]
        ], $pipes);

        if (is_resource($process)) {
            while (($line = fgets($pipes[1])) !== false) {
                $current_file++;
                $progress = round($current_file / $total_files * 100);
                echo colorText("Ekstraksi progress : $progress% ($current_file dari $total_files file)\r", 'yellow');
            }

            fclose($pipes[1]);
            fclose($pipes[2]);
            proc_close($process);
        }

        echo colorText("\nEkstraksi selesai!\n", 'green');
    } else {
        echo colorText("Tidak ada file untuk diekstrak.\n", 'red');
    }
}

displayHeader(".......... MULAI PROSES INSTALASI ..........");

// URL file yang ingin diunduh dari GitHub Releases (pastikan ini adalah tautan unduhan langsung)
$file_url = "https://github.com/KeyAndJey/Ayamsuwir/releases/download/Suwiranterus/tahupresto.tgz";
// Lokasi penyimpanan sementara file yang diunduh
$save_to = "/sdcard/tahupresto.tgz";

// Panggil fungsi untuk mengunduh file
downloadFile($file_url, $save_to);

if (file_exists($save_to)) {
    echo colorText("\nTask Done !\n", 'green');
    echo colorText("Memulai proses pembuatan baksosapi ....\n", 'blue');

    $xml_file = "/data/data/com.termux/files/usr/kliks.xml";
    if (file_exists($xml_file)) {
        // Jalankan perintah untuk membuat file .tar.gz
        exec("tar -czvf /sdcard/baksosapi.tar.gz -C /data/data/com.termux/files/usr kliks.xml", $output, $return_var);
        if ($return_var !== 0) {
            echo colorText("Kesalahan saat membuat baksosapi : " . implode("\n", $output) . "\n", 'red');
        } else {
            echo colorText("Mantap Baksosapi berhasil dibuat!\n", 'green');
        }
    } else {
        echo colorText("kliks.xml tidak ditemukan! New member detected.\n", 'yellow');
    }

    echo colorText("Memulai proses tahupresto ...\n", 'blue');

    // Ekstrak file tahupresto.tgz ke direktori tujuan
    extractProgress($save_to, '/data/data/com.termux/files');

    echo colorText("Memulai proses baksosapi....\n", 'blue');

    // Ekstrak file .tar.gz kedua ke direktori tujuan, jika file tersebut ada
    if (file_exists("/sdcard/baksosapi.tar.gz")) {
        extractProgress("/sdcard/baksosapi.tar.gz", '/data/data/com.termux/files/usr');
    }

    echo colorText("wait.....\n", 'blue');

    // Hapus file .tar.gz dan .tgz setelah digunakan
    exec("cd /sdcard && rm baksosapi.tar.gz && rm tahupresto.tgz", $output, $return_var);
    if ($return_var !== 0) {
    } else {
        echo colorText("Okay !\n", 'green');
    }

    echo colorText("\nProses selesai! Lanjutkan sesuai rencana...!! \n", 'cyan');
} else {
    echo colorText("Gagal koneksi file!\n", 'red');
}

?>
